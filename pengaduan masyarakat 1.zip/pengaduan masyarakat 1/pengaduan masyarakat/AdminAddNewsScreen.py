from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup
from kivy.uix.image import Image

news_data = []

# Halaman Admin untuk Menambah Berita
class AdminAddNewsScreen(Screen):
    def __init__(self, **kwargs):
        super(AdminAddNewsScreen, self).__init__(**kwargs)

        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Input untuk judul berita
        self.title_input = TextInput(hint_text="Judul Berita", font_size=24, multiline=False, size_hint_y=None, height=50)
        layout.add_widget(self.title_input)

        # Input untuk konten berita
        self.content_input = TextInput(hint_text="Isi Konten Berita", font_size=18, size_hint_y=None, height=100)
        layout.add_widget(self.content_input)

        # Pilih gambar berita
        file_chooser_layout = BoxLayout(orientation='vertical')
        file_chooser_layout.add_widget(Label(text="Pilih Gambar:", font_size=24))
        self.file_chooser = FileChooserListView(size_hint=(1, 0.5))
        file_chooser_layout.add_widget(self.file_chooser)
        layout.add_widget(file_chooser_layout)

        # Tombol untuk menambahkan berita
        add_button = Button(text="Tambahkan Berita", size_hint=(1, 0.1), font_size=20)
        add_button.bind(on_press=self.add_news)
        layout.add_widget(add_button)

        # Tombol kembali ke halaman berita
        back_button = Button(text='Kembali ke Beranda', size_hint=(1, 0.1), font_size=20)
        back_button.bind(on_press=lambda x: setattr(self.manager, 'current', 'homeadmin'))
        layout.add_widget(back_button)

        self.add_widget(layout)

    def add_news(self, instance):
        title = self.title_input.text
        content = self.content_input.text
        image_path = self.file_chooser.selection[0] if self.file_chooser.selection else None

        if title and content:
            # Memasukkan berita ke dalam daftar berita global
            news_screen = self.manager.get_screen('berita')
            news_screen.add_news(title, content, image_path)

            # Reset input setelah menambahkan berita
            self.title_input.text = ''
            self.content_input.text = ''
            self.file_chooser.selection = []

            # Kembali ke halaman berita
            self.manager.current = 'beranda'

# Aplikasi Utama
class TestApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(AdminAddNewsScreen(name='berita'))  # Menambahkan NewsScreen di sini
        return sm
if __name__ == '__main__':
    TestApp().run()
