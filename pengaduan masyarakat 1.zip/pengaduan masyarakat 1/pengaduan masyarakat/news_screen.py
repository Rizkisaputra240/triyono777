from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView

# Halaman Utama Berita
class NewsScreen(Screen):
    def __init__(self, **kwargs):
        super(NewsScreen, self).__init__(**kwargs)

        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Judul halaman
        header = BoxLayout(orientation='vertical', size_hint=(1, 0.2))
        header.add_widget(Label(text='Berita Desa', font_size=34, bold=True))
        header.add_widget(Label(text='Menyajikan informasi terbaru tentang peristiwa, \nberita terkini', font_size=24))
        layout.add_widget(header)

        # ScrollView untuk membuat daftar berita bisa di-scroll
        scroll_view = ScrollView(size_hint=(1, 0.7))

        news_layout = BoxLayout(orientation='vertical', spacing=10, padding=10, size_hint_y=None)
        news_layout.bind(minimum_height=news_layout.setter('height'))

        # Contoh berita pertama
        news1 = BoxLayout(orientation='vertical', size_hint_y=None, height=400, spacing=10)
        news1.add_widget(Image(source='images/17agustus.png', size_hint=(1, 0.9)))
        news1.add_widget(Label(text='Merayakan Kemerdekaan RI Ke-79 di desa Cengklik', font_size=24))

        button1 = Button(text='Baca Selengkapnya', size_hint=(1, 0.3))
        button1.bind(on_press=self.show_more_news_1)
        news1.add_widget(button1)

        news_layout.add_widget(news1)

        # Contoh berita kedua
        news2 = BoxLayout(orientation='vertical', size_hint_y=None, height=400, spacing=10)
        news2.add_widget(Image(source='images/gotongroyong.jpeg', size_hint=(1, 0.9)))
        news2.add_widget(Label(text='Di Desa Cengklik, gotong royong bukan sekadar tradisi', font_size=24))

        button2 = Button(text='Baca Selengkapnya', size_hint=(1, 0.3))
        button2.bind(on_press=self.show_more_news_2)
        news2.add_widget(button2)

        news_layout.add_widget(news2)

        scroll_view.add_widget(news_layout)
        layout.add_widget(scroll_view)

        # Navigasi
        button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10)
        button_layout.add_widget(Button(text='BERANDA', size_hint=(1, 1), on_press=self.go_to_home))  # Pindah ke Beranda
        button_layout.add_widget(Button(text='PENGADUAN', size_hint=(1, 1), on_press=self.go_to_complaint))  # Pindah ke Pengaduan
        button_layout.add_widget(Button(text='BERITA', size_hint=(1, 1)))  # Tetap di halaman berita

        layout.add_widget(button_layout)

        self.add_widget(layout)

    def go_to_home(self, instance):
        self.manager.current = 'home'  # Ganti dengan nama layar beranda Anda

    def go_to_complaint(self, instance):
        self.manager.current = 'complaint'  # Ganti dengan nama layar pengaduan Anda

    def show_more_news_1(self, instance):
        # Menampilkan layar berita pertama
        self.manager.current = 'news_detail_1'

    def show_more_news_2(self, instance):
        # Menampilkan layar berita kedua
        self.manager.current = 'news_detail_2'


# Layar Detail Berita 1
class NewsDetailScreen1(Screen):
    def __init__(self, **kwargs):
        super(NewsDetailScreen1, self).__init__(**kwargs)

        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Kotak untuk menampung berita
        news_box = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Tambahkan judul berita
        news_box.add_widget(Label(text="Perayaan Kemerdekaan RI di Desa Cengklik", font_size=34, bold=True))

        # Tambahkan gambar berita
        news_box.add_widget(Image(source='images/17agustus.png', size_hint=(1, 0.7)))

        # Tambahkan konten berita
        news_box.add_widget(Label(
            text="Pada perayaan tahun ini, Desa Cengklik mengadakan berbagai lomba yang sangat seru dan diikuti oleh warga desa...",
            font_size=20
        ))

        layout.add_widget(news_box)

        # Tombol kembali
        back_button = Button(text='Kembali ke Berita', size_hint=(1, 0.1))
        back_button.bind(on_press=self.go_back)
        layout.add_widget(back_button)

        self.add_widget(layout)

    def go_back(self, instance):
        self.manager.current = 'news'


# Layar Detail Berita 2
class NewsDetailScreen2(Screen):
    def __init__(self, **kwargs):
        super(NewsDetailScreen2, self).__init__(**kwargs)

        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Kotak untuk menampung berita
        news_box = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Tambahkan judul berita
        news_box.add_widget(Label(text="Gotong Royong di Desa Cengklik", font_size=34, bold=True))

        # Tambahkan gambar berita
        news_box.add_widget(Image(source='images/gotongroyong.jpeg', size_hint=(1, 0.7)))

        # Tambahkan konten berita
        news_box.add_widget(Label(
            text="Gotong royong di Desa Cengklik berlangsung rutin setiap bulan. Masyarakat berpartisipasi untuk membersihkan lingkungan sekitar...",
            font_size=20
        ))

        layout.add_widget(news_box)

        # Tombol kembali
        back_button = Button(text='Kembali ke Berita', size_hint=(1, 0.1))
        back_button.bind(on_press=self.go_back)
        layout.add_widget(back_button)

        self.add_widget(layout)

    def go_back(self, instance):
        self.manager.current = 'news'


# Aplikasi Utama
class TestApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(NewsScreen(name='news'))
        sm.add_widget(NewsDetailScreen1(name='news_detail_1'))
        sm.add_widget(NewsDetailScreen2(name='news_detail_2'))
        return sm

if __name__ == '__main__':
    TestApp().run()
