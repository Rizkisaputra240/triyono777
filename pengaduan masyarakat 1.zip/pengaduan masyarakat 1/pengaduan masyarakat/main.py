from kivy.app import App
from kivy.uix.screenmanager import ScreenManager
from login_screen import LoginScreen
from register_screen import RegisterScreen
from home_screen import HomeScreen
from news_screen import NewsScreen
from complaint_screen import ComplaintScreen
from confirmation_screen import ConfirmationScreen  # Import layar konfirmasi
from news_screen import NewsDetailScreen1
from news_screen import NewsDetailScreen2
from ProfileScreen import ProfileScreen 
from VillageProfileScreen import VillageProfileScreen
from InfographicScreen import InfographicScreen
from AdminScreen import HomeAdminScreen
from AdminAddNewsScreen import AdminAddNewsScreen
from AdminComplaintScreen import AdminComplaintScreen

class MyApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(HomeScreen(name='home'))
        sm.add_widget(ComplaintScreen(name='complaint'))
        sm.add_widget(NewsScreen(name='news'))
        sm.add_widget(NewsDetailScreen1(name='news_detail_1'))
        sm.add_widget(NewsDetailScreen2(name='news_detail_2'))
        sm.add_widget(ConfirmationScreen(name='confirmation')) 
        sm.add_widget(ProfileScreen(name='profile')) # Tambahkan layar konfirmasi
        sm.add_widget(VillageProfileScreen(name='VillageProfile'))
        sm.add_widget(InfographicScreen(name='InfographicScreen'))
        sm.add_widget(HomeAdminScreen(name='homeadmin'))
        sm.add_widget(AdminAddNewsScreen(name='adminaddnews'))
        sm.add_widget(AdminComplaintScreen(name='admincomplaint'))

        # Debugging print untuk memeriksa layar yang didaftarkan
        print("Layar yang terdaftar:", sm.screen_names)


        return sm

if __name__ == '__main__':
    MyApp().run()
