from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.spinner import Spinner

class RegisterScreen(Screen):
    def __init__(self, **kwargs):
        super(RegisterScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=[40, 20, 40, 20], spacing=20)

        layout.add_widget(Image(source='images/DESA CENGKLIK.png', size_hint=(1, 0.3)))
        layout.add_widget(Label(text='Daftarkan Akun Anda', font_size=24, size_hint=(1, 0.2)))

        self.name_input = TextInput(hint_text='Nama Lengkap', multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.name_input)

        self.TanggalLahir_input = TextInput(hint_text='Tanggal Lahir', multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.TanggalLahir_input)


        self.tempatlahir_input = TextInput(hint_text='Tempat Lahir', multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.tempatlahir_input)

          # Pilihan Jenis Kelamin menggunakan Spinner
        self.jenis_kelamin_spinner = Spinner(
            text='Pilih Jenis Kelamin',
            values=('Laki-laki', 'Perempuan'),
            size_hint=(1, 0.1)
        )
        layout.add_widget(self.jenis_kelamin_spinner)

        self.agama_input = TextInput(hint_text='Agama', password=True, multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.agama_input)

        self.alamat_input = TextInput(hint_text='Alamat', password=True, multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.alamat_input)

        self.email_input = TextInput(hint_text='Email', password=True, multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.email_input)

        self.sandi_input = TextInput(hint_text='Sandi', password=True, multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.sandi_input)

        register_button = Button(text='DAFTAR', size_hint=(1, 0.1), background_color=(0, 0, 1, 1))
        register_button.bind(on_press=self.register_user)  # Bind ke fungsi register_user
        layout.add_widget(register_button)

        box = BoxLayout(orientation='horizontal', size_hint=(1, 0.1))
        box.add_widget(Label(text='Sudah memiliki Akun?'))
        login_button = Button(text='Masuk', size_hint=(None, None), size=(80, 40), color=(0, 0, 1, 1))
        login_button.bind(on_press=self.go_to_login)
        box.add_widget(login_button)

        layout.add_widget(box)
        self.add_widget(layout)

    def register_user(self, instance):
    # Logika validasi register (misalnya cek apakah semua input terisi)
        if self.sandi_input.text == self.sandi_input.text:  # Cek password sesuai dengan konfirmasi password
        # Jika validasi berhasil, ganti layar ke home
            self.manager.current = 'home'
        else:
            print("Password tidak cocok")


    def go_to_login(self, instance):
        self.manager.current = 'login'  # Kembali ke layar login
