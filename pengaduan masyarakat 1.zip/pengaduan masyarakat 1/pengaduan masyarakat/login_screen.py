# login_screen.py
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from home_screen import HomeScreen # Impor AdminScreen dari file admin_screen.py
from AdminScreen import HomeAdminScreen

class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super(LoginScreen, self).__init__(**kwargs)
        
        layout = BoxLayout(orientation='vertical', padding=[40, 20, 40, 20], spacing=20)
        layout.add_widget(Image(source='images/DESA CENGKLIK.png', size_hint=(1, 0.3)))
        layout.add_widget(Label(text='Aplikasi Pengaduan Masyarakat', font_size=24, size_hint=(1, 0.2)))

        self.email_input = TextInput(hint_text='Email', multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.email_input)

        self.password_input = TextInput(hint_text='Kata Sandi', password=True, multiline=False, size_hint=(1, 0.1))
        layout.add_widget(self.password_input)

        login_button = Button(text='Log in', size_hint=(1, 0.1), background_color=(0, 0, 1, 1))
        login_button.bind(on_press=self.login)
        layout.add_widget(login_button)

        box = BoxLayout(orientation='horizontal', size_hint=(1, 0.1))
        box.add_widget(Label(text='belum memiliki akun?'))
        register_button = Button(text='Daftar', size_hint=(None, None), size=(80, 40), color=(0, 0, 1, 1))
        register_button.bind(on_press=self.go_to_register)
        box.add_widget(register_button)

        layout.add_widget(box)
        self.add_widget(layout)

    def login(self, instance):
        email = self.email_input.text
        password = self.password_input.text
        print("Login dengan email:", email)

        if email == "admin@desa.com" and password == "admin123":
            # Arahkan ke halaman admin jika login berhasil
            self.manager.current = 'homeadmin'
        elif email != "user@desa.com" and password == "user123":
            self.manager.current = 'home'
        else:
            popup = Popup(title='Login Failed', content=Label(text='Email atau Password salah!'),
                          size_hint=(None, None), size=(400, 200))
            popup.open()

    def go_to_register(self, instance):
        self.manager.current = 'register'


# Aplikasi Login
class TestApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))  # Halaman login
        sm.add_widget(HomeScreen(name='home'))
        sm.add_widget(HomeAdminScreen(name='homeadmin'))# Halaman admin, diimpor dari file admin_screen.py
        return sm

if __name__ == '__main__':
    TestApp().run()
