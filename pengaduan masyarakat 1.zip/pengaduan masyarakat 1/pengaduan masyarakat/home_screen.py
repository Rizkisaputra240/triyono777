from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.popup import Popup

class HomeScreen(Screen):
    def __init__(self, **kwargs):
        super(HomeScreen, self).__init__(**kwargs)
        
        layout = FloatLayout()
        # Menu layout (hidden by default)
        self.menu_layout = BoxLayout(orientation='vertical', size_hint=(0.7, 1), pos_hint={'x': -0.7, 'top': 1}, padding=[10, 570, 550, 570], spacing=10)
        # padding=[left, top, right, bottom] untuk mengatur jarak padding dari semua sisi

        self.menu_layout.add_widget(Button(text="Profil Anda", size_hint_y=None, height=50, on_press=self.go_to_profile))
        self.menu_layout.add_widget(Button(text="Profil Desa", size_hint_y=None, height=50, on_press=self.go_to_village_profile))
        self.menu_layout.add_widget(Button(text="Infographic", size_hint_y=None, height=50, on_press=self.go_to_infographic))
        self.menu_layout.add_widget(Button(text="Log Out", on_press=self.show_logout_confirmation, size_hint_y=None, height=50))

        layout.add_widget(self.menu_layout)

        # Button to toggle menu (Hamburger Icon)
        self.menu_button = Button(text='☰', size_hint=(0.1, 0.1), pos_hint={'x': 0, 'top': 1})
        self.menu_button.bind(on_press=self.toggle_menu)
        layout.add_widget(self.menu_button)

        # Informasi Kepala Desa
        head_layout = BoxLayout(orientation='vertical', size_hint=(0.9, 0.3), padding=10, pos_hint={'center_x': 0.5, 'top': 0.85})
        
        # Menambahkan gambar profil di tengah atas
        head_image = Image(source='images/profil.png', size_hint=(None, None), size=(100, 100))
        head_image.pos_hint = {'center_x': 0.5, 'top': 1}  # Pusatkan gambar secara horizontal dan posisikan di atas
        head_layout.add_widget(head_image)
        head_layout.add_widget(Label(text='SAMBUTAN KEPALA DESA', font_size=20, bold=True, halign='center'))
        head_layout.add_widget(Label(text='SUPARMAN', font_size=18, bold=True, halign='center'))
        head_layout.add_widget(Label(text='P.J. KEPLALA DESA CENGKLIK', font_size=16, halign='center'))

        layout.add_widget(head_layout)

        # Area untuk peta desa
        map_area = BoxLayout(orientation='vertical', size_hint=(0.9, 0.4), padding=10, pos_hint={'center_x': 0.5, 'top': 0.55})
        map_area.add_widget(Label(text='PETA DESA', font_size=20, size_hint_y=None, height=40, halign='center'))
        # Ganti label dengan image peta
        map_image = Image(source='images/peta.png', size_hint=(1, None), size=(350, 200))  # Sesuaikan ukuran gambar peta
        map_area.add_widget(map_image)

        layout.add_widget(map_area)

        # Navigasi
        button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10, pos_hint={'center_x': 0.5, 'y': 0})  # Menambahkan spacing untuk tombol
        button_layout.add_widget(Button(text='BERANDA', size_hint=(1, 1), on_press=self.go_to_home))
        button_layout.add_widget(Button(text='PENGADUAN', size_hint=(1, 1), on_press=self.go_to_complaint))
        button_layout.add_widget(Button(text='BERITA', size_hint=(1, 1), on_press=self.go_to_news))  # Navigasi ke halaman berita

        layout.add_widget(button_layout)

        self.add_widget(layout)

    def toggle_menu(self, instance):
        # Menggerakkan menu ke dalam dan keluar
        if self.menu_layout.pos_hint['x'] == -0.7:
            # Show menu
            self.menu_layout.pos_hint = {'x': 0, 'top': 1}
        else:
            # Hide menu
            self.menu_layout.pos_hint = {'x': -0.7, 'top': 1}
        self.menu_layout.canvas.ask_update()

    def show_logout_confirmation(self, instance):
        # Popup to confirm logout
        content = BoxLayout(orientation='vertical', padding=10)
        content.add_widget(Label(text='Ingin Logout Dari Akun Sekarang?'))
        button_layout = BoxLayout(size_hint=(1, 0.2))
        button_layout.add_widget(Button(text='Tidak', on_press=lambda x: self.dismiss_popup()))
        button_layout.add_widget(Button(text='Ya', on_press=self.logout))
        content.add_widget(button_layout)
        
        self.popup = Popup(title='Konfirmasi', content=content, size_hint=(0.8, 0.4))
        self.popup.open()

    def dismiss_popup(self):
        self.popup.dismiss()

    def logout(self, instance):
        self.manager.current = 'login'  # Kembali ke halaman login
        self.popup.dismiss()

    def go_to_home(self, instance):
        self.manager.current = 'home'  # Pindah ke halaman beranda

    def go_to_complaint(self, instance):
        self.manager.current = 'complaint'  # Pindah ke halaman pengaduan

    def go_to_news(self, instance):
        self.manager.current = 'news'  # Pindah ke halaman berita

    def go_to_profile(self, instance):
        self.manager.current = 'profile' # pindah ke halaman profil

    def go_to_village_profile(self, instance):
        self.manager.current = 'VillageProfile' # pindah ke halaman profil

    def go_to_infographic(self, instance):
        self.manager.current = 'InfographicScreen' # Tambahkan logika untuk navigasi ke halaman Infografis

