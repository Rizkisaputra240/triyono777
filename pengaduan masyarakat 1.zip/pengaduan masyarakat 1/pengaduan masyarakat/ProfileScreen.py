from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.spinner import Spinner
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup
from kivy.uix.floatlayout import FloatLayout


class ProfileScreen(Screen):
    def __init__(self, **kwargs):
        super(ProfileScreen, self).__init__(**kwargs)

        layout = FloatLayout()

        # Layout menu (tersembunyi secara default)
        self.menu_layout = BoxLayout(orientation='vertical', size_hint=(0.7, 1), pos_hint={'x': -0.7, 'top': 1}, padding=[10, 570, 550, 570], spacing=10)

        self.menu_layout.add_widget(Button(text="Profil Anda", size_hint_y=None, height=50, on_press=self.go_to_profile))
        self.menu_layout.add_widget(Button(text="Profil Desa", size_hint_y=None, height=50, on_press=self.go_to_village_profile))
        self.menu_layout.add_widget(Button(text="Infographic", size_hint_y=None, height=50, on_press=self.go_to_infographic))
        self.menu_layout.add_widget(Button(text="Log Out", on_press=self.show_logout_confirmation, size_hint_y=None, height=50))

        layout.add_widget(self.menu_layout)

        # Tombol untuk mengganti menu (Hamburger Icon)
        self.menu_button = Button(text='☰', size_hint=(0.1, 0.1), pos_hint={'x': 0, 'top': 1})
        self.menu_button.bind(on_press=self.toggle_menu)
        layout.add_widget(self.menu_button)

        # Layout utama untuk halaman profil
        profile_layout = BoxLayout(orientation='vertical', padding=[20, 20, 20, 200], spacing=10) 
        
        # Gambar Profil di tengah
        profile_image_layout = AnchorLayout(anchor_x='center', anchor_y='center')
        self.profile_image = Image(source='images/default_profile.png', size_hint=(None, None), size=(150, 150))
        profile_image_layout.add_widget(self.profile_image)

        change_photo_button = Button(text='Ganti Foto', size_hint=(None, None), size=(150, 40), on_press=self.change_photo)
        profile_image_layout.add_widget(change_photo_button)

        profile_layout.add_widget(profile_image_layout)

        # Input untuk Nama, Tanggal Lahir, dll.
        profile_layout.add_widget(self.create_input_row("Nama Lengkap", "Masukkan nama lengkap"))
        profile_layout.add_widget(self.create_input_row("Tanggal Lahir", "Masukkan tanggal lahir"))
        profile_layout.add_widget(self.create_input_row("Tempat Lahir", "Masukkan tempat lahir"))
        profile_layout.add_widget(self.create_input_row("Jenis Kelamin", "Pilih jenis kelamin", is_spinner=True))
        profile_layout.add_widget(self.create_input_row("Agama", "Masukkan agama"))
        profile_layout.add_widget(self.create_input_row("Alamat", "Masukkan alamat"))
        profile_layout.add_widget(self.create_input_row("Email", "Masukkan email"))
        profile_layout.add_widget(self.create_input_row("Sandi", "Masukkan sandi", is_password=True))
        

        # Navigasi
        button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10, pos_hint={'center_x': 0.5, 'y': 0})  # Menambahkan spacing untuk tombol
        button_layout.add_widget(Button(text='BERANDA', size_hint=(1, 1), on_press=self.go_to_home))
        button_layout.add_widget(Button(text='PENGADUAN', size_hint=(1, 1), on_press=self.go_to_complaint))
        button_layout.add_widget(Button(text='BERITA', size_hint=(1, 1), on_press=self.go_to_news))  # Navigasi ke halaman berita

        layout.add_widget(button_layout)

        layout.add_widget(profile_layout)

        self.add_widget(layout)

    def create_input_row(self, label_text, hint_text, is_spinner=False, is_password=False):
        row = BoxLayout(size_hint_y=None, height=50, spacing=20)
        label = Label(text=label_text, size_hint_x=0.1)  # Ukuran label
        if is_spinner:
            input_widget = Spinner(text=hint_text, values=("Laki-laki", "Perempuan"), size_hint_x=0.7)
        else:
            input_widget = TextInput(hint_text=hint_text, multiline=False, password=is_password, size_hint_x=0.7)
        row.add_widget(label)
        row.add_widget(input_widget)
        return row

    def toggle_menu(self, instance):
        # Menggerakkan menu ke dalam dan keluar
        if self.menu_layout.pos_hint['x'] == -0.7:
            # Menampilkan menu
            self.menu_layout.pos_hint = {'x': 0, 'top': 1}
        else:
            # Menyembunyikan menu
            self.menu_layout.pos_hint = {'x': -0.7, 'top': 1}
        self.menu_layout.canvas.ask_update()

    def open_menu(self, instance):
        print("Hamburger menu dibuka")

    # Fungsi untuk mengubah foto profil
    def change_photo(self, instance):
        # Popup file chooser untuk memilih foto
        file_chooser = FileChooserListView(filters=["*.png", "*.jpg", "*.jpeg"])
        popup = Popup(title="Pilih Foto Profil", content=file_chooser, size_hint=(0.9, 0.9))
        file_chooser.bind(on_selection=lambda x, y: self.update_photo(y, popup))
        popup.open()

    def update_photo(self, selected_file, popup):
        if selected_file:
            self.profile_image.source = selected_file[0]  # Ganti source image dengan foto terpilih
        popup.dismiss()

    # Navigasi ke halaman lain
    def go_to_home(self, instance):
        self.manager.current = 'home'

    def go_to_complaint(self, instance):
        self.manager.current = 'complaint'

    def go_to_news(self, instance):
        self.manager.current = 'news'

    def go_to_profile(self, instance):
        self.manager.current = 'profile'

    def go_to_village_profile(self, instance):
        self.manager.current = 'VillageProfile'  # Perbaiki pengetikan dari 'VilageProfile'

    def go_to_infographic(self, instance):
        self.manager.current = 'InfographicScreen' # Tambahkan logika untuk navigasi ke halaman Infografis

    def show_logout_confirmation(self, instance):
        # Popup untuk konfirmasi logout
        content = BoxLayout(orientation='vertical', padding=10)
        content.add_widget(Label(text='Ingin Logout Dari Akun Sekarang?'))
        button_layout = BoxLayout(size_hint=(1, 0.2))
        button_layout.add_widget(Button(text='Tidak', on_press=lambda x: self.dismiss_popup()))
        button_layout.add_widget(Button(text='Ya', on_press=self.logout))
        content.add_widget(button_layout)

        self.popup = Popup(title='Konfirmasi', content=content, size_hint=(0.8, 0.4))
        self.popup.open()

    def dismiss_popup(self):
        self.popup.dismiss()

    def logout(self, instance):
        self.manager.current = 'login'  # Kembali ke halaman login
        self.popup.dismiss()
