from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup


class ComplaintScreen(Screen):
    def __init__(self, **kwargs):
        super(ComplaintScreen, self).__init__(**kwargs)

        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Tambahkan label judul
        layout.add_widget(Label(text='FORMULIR PENGADUAN', font_size=24, size_hint=(1, 0.2)))

        # Spinner untuk kategori pengaduan
        category_spinner = Spinner(
            text='Kategori Pengaduan',
            values=('Infrastruktur', 'Kesehatan', 'Keamanan', 'Lainnya'),
            size_hint=(1, 0.1)
        )
        layout.add_widget(category_spinner)

        # Spinner untuk lokasi
        location_spinner = Spinner(
            text='Lokasi',
            values=('Desa A', 'Desa B', 'Desa C', 'Lainnya'),
            size_hint=(1, 0.1)
        )
        layout.add_widget(location_spinner)

        # TextInput untuk deskripsi pengaduan
        self.description_input = TextInput(hint_text='Deskripsi Pengaduan', size_hint=(1, 0.3), multiline=True)
        layout.add_widget(self.description_input)

        # Tombol untuk unggah file foto/video
        upload_button = Button(text='Unggah foto/Video', size_hint=(1, 0.1), background_color=(0.7, 0.7, 0.7, 1))
        upload_button.bind(on_press=self.open_file_chooser)
        layout.add_widget(upload_button)

        # Tombol kirim
        submit_button = Button(text='Kirim', size_hint=(1, 0.1), background_color=(0, 0, 1, 1))
        submit_button.bind(on_press=self.go_to_confirmation)  # Menuju halaman konfirmasi
        layout.add_widget(submit_button)

        # Navigasi
        button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10)
        button_layout.add_widget(Button(text='BERANDA', size_hint=(1, 1), on_press=self.go_to_home))
        button_layout.add_widget(Button(text='PENGADUAN', size_hint=(1, 1), on_press=self.go_to_complaint))
        button_layout.add_widget(Button(text='BERITA', size_hint=(1, 1), on_press=self.go_to_news))

        layout.add_widget(button_layout)

        self.add_widget(layout)

    def open_file_chooser(self, instance):
        file_chooser = FileChooserListView(filters=["*.png", "*.jpg", "*.jpeg", "*.mp4", "*.avi"])
        popup = Popup(title="Pilih Foto/Video", content=file_chooser, size_hint=(0.9, 0.9))
        file_chooser.bind(on_selection=lambda x, y: self.update_file_selection(y, popup))
        popup.open()

    def update_file_selection(self, selected_file, popup):
        if selected_file:
            # Anda bisa menambahkan logika di sini untuk menyimpan file yang dipilih
            print(f"File yang dipilih: {selected_file[0]}")
            # Misalnya, Anda bisa menambahkan label untuk menampilkan nama file
            self.description_input.text += f"\nFile yang dipilih: {selected_file[0]}"
        popup.dismiss()

    def go_to_confirmation(self, instance):
        self.manager.current = 'confirmation'  # Mengganti layar ke konfirmasi pengaduan

    def go_to_home(self, instance):
        self.manager.current = 'home'  # Navigasi ke beranda

    def go_to_complaint(self, instance):
        self.manager.current = 'complaint'  # Tetap di halaman pengaduan

    def go_to_news(self, instance):
        self.manager.current = 'news'  # Navigasi ke halaman berita
