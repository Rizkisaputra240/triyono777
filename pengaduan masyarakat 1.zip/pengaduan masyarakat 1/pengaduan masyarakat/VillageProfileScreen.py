from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.popup import Popup

class VillageProfileScreen(Screen):
    def __init__(self, **kwargs):
        super(VillageProfileScreen, self).__init__(**kwargs)

        layout = FloatLayout()
        # Menu layout (hidden by default)
        self.menu_layout = BoxLayout(orientation='vertical', size_hint=(0.7, 1), pos_hint={'x': -0.7, 'top': 1}, padding=[10, 570, 550, 570], spacing=10)
        # padding=[left, top, right, bottom] untuk mengatur jarak padding dari semua sisi

        self.menu_layout.add_widget(Button(text="Profil Anda", size_hint_y=None, height=50, on_press=self.go_to_profile))
        self.menu_layout.add_widget(Button(text="Profil Desa", size_hint_y=None, height=50, on_press=self.go_to_village_profile))
        self.menu_layout.add_widget(Button(text="Infographic", size_hint_y=None, height=50, on_press=self.go_to_infographic))
        self.menu_layout.add_widget(Button(text="Log Out", on_press=self.show_logout_confirmation, size_hint_y=None, height=50))

        layout.add_widget(self.menu_layout)


        # Button to toggle menu (Hamburger Icon)
        self.menu_button = Button(text='☰', size_hint=(0.1, 0.1), pos_hint={'x': 0, 'top': 1})
        self.menu_button.bind(on_press=self.toggle_menu)
        layout.add_widget(self.menu_button)

        # ScrollView untuk menghindari tumpang tindih
        scroll_layout = BoxLayout(orientation='vertical', size_hint=(1, None))
        scroll_layout.bind(minimum_height=scroll_layout.setter('height'))


        # Bagian atas: foto kepala desa dan info
        header_layout = BoxLayout(orientation='vertical', size_hint_y=None, size_hint=(0.9, 0.3), padding=10, pos_hint={'center_x': 0.8, 'top': 0.85})
       
        # Layout horizontal untuk gambar dan informasi
        profile_layout = BoxLayout(orientation='horizontal', size_hint_y=None, height=150)
        profile_layout.add_widget(Image(source='images/profil.png', size_hint=(0.3, 1)))  # Ganti dengan path gambar yang sesuai

        # Info Kepala Desa
        info_layout = BoxLayout(orientation='vertical', padding=(10, 20, 600, 10))  # Padding atas 20
        info_layout.add_widget(Label(text='SUPARMAN', bold=True, font_size=20, halign='center'))
        info_layout.add_widget(Label(text='P.J. KEPALA DESA CENGKLIK', bold=True, font_size=16, halign='center'))
        profile_layout.add_widget(info_layout)


        header_layout.add_widget(profile_layout)
        scroll_layout.add_widget(header_layout)

        # Tombol untuk navigasi ke bagian Visi, Misi, dan Sejarah
        button_layout = BoxLayout(orientation='vertical', size_hint=(0.5, None), height=200, spacing=10, pos_hint={'center_x': 0.5})
        visi_button = Button(text='Visi', on_press=self.show_vision)
        misi_button = Button(text='Misi', on_press=self.show_mision)
        sejarah_button = Button(text='Sejarah Desa', on_press=self.show_village_history)
        button_layout.add_widget(visi_button)
        button_layout.add_widget(misi_button)
        button_layout.add_widget(sejarah_button)
        scroll_layout.add_widget(button_layout)

        # Area untuk menampilkan teks Visi, Misi, dan Sejarah
        self.info_display = BoxLayout(orientation='vertical', size_hint_y=None, height=100)
        scroll_layout.add_widget(self.info_display)

        # Peta Desa
        peta_layout = BoxLayout(orientation='vertical', size_hint_y=None, height=350,)
        peta_layout.add_widget(Label(text='Peta Desa', font_size=20, size_hint_y=None, height=50))
        peta_layout.add_widget(Label(size_hint_y=None, height=2))  # Spacer dengan tinggi 20
        self.village_map_image = Image(source='images/peta.png', size_hint=(1, 1))  # Ganti dengan path gambar peta yang sesuai
        peta_layout.add_widget(self.village_map_image)
        scroll_layout.add_widget(peta_layout)

        layout.add_widget(scroll_layout)

        # Navigasi
        nav_button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10)
        nav_button_layout.add_widget(Button(text='BERANDA', size_hint=(1, 1), on_press=self.go_to_home))
        nav_button_layout.add_widget(Button(text='PENGADUAN', size_hint=(1, 1), on_press=self.go_to_complaint))
        nav_button_layout.add_widget(Button(text='BERITA', size_hint=(1, 1), on_press=self.go_to_news))

        layout.add_widget(nav_button_layout)

        self.add_widget(layout)

    def toggle_menu(self, instance):
        # Menggerakkan menu ke dalam dan keluar
        if self.menu_layout.pos_hint['x'] == -0.5:
            self.menu_layout.pos_hint = {'x': 0, 'top': 1}  # Show menu
        else:
            self.menu_layout.pos_hint = {'x': -0.5, 'top': 1}  # Hide menu

    def show_logout_confirmation(self, instance):
        # Popup to confirm logout
        content = BoxLayout(orientation='vertical', padding=10)
        content.add_widget(Label(text='Ingin Logout Dari Akun Sekarang?'))
        button_layout = BoxLayout(size_hint=(1, 0.2))
        button_layout.add_widget(Button(text='Tidak', on_press=lambda x: self.dismiss_popup()))
        button_layout.add_widget(Button(text='Ya', on_press=self.logout))
        content.add_widget(button_layout)
        
        self.popup = Popup(title='Konfirmasi', content=content, size_hint=(0.8, 0.4))
        self.popup.open()

    def dismiss_popup(self):
        self.popup.dismiss()

    def logout(self, instance):
        self.manager.current = 'login'  # Kembali ke halaman login
        self.popup.dismiss()

    def go_to_home(self, instance):
        self.manager.current = 'home'  # Navigasi ke beranda

    def go_to_complaint(self, instance):
        self.manager.current = 'complaint'  # Navigasi ke halaman pengaduan

    def go_to_news(self, instance):
        self.manager.current = 'news'  # Navigasi ke halaman berita

    def go_to_profile(self, instance):
        self.manager.current = 'profile'  # Navigasi ke profil Anda

    def go_to_village_profile(self, instance):
        self.manager.current = 'VillageProfile'  # Perbaiki pengetikan dari 'VilageProfile'

    def go_to_infographic(self, instance):
        self.manager.current = 'InfographicScreen' # Tambahkan logika untuk navigasi ke halaman Infografis


    def show_vision(self, instance):
        self.info_display.clear_widgets()  # Kosongkan area tampilan
        self.info_display.add_widget(Label(text='Visi Desa', font_size=22))
        self.info_display.add_widget(Label(text='Mewujudkan desa yang sejahtera dan mandiri.', size_hint_y=None, height=30))

    def show_mision(self, instance):
        self.info_display.clear_widgets()  # Kosongkan area tampilan
        self.info_display.add_widget(Label(text='Misi Desa', font_size=22))
        self.info_display.add_widget(Label(text='1. Meningkatkan kualitas pelayanan publik.', size_hint_y=None, height=30))
        self.info_display.add_widget(Label(text='2. Mendorong partisipasi masyarakat.', size_hint_y=None, height=30))

    def show_village_history(self, instance):
        self.info_display.clear_widgets()  # Kosongkan area tampilan
        self.info_display.add_widget(Label(text='Sejarah Desa', font_size=22))
        self.info_display.add_widget(Label(text='Desa Cengklik didirikan pada tahun 1980...', size_hint_y=None, height=30))
