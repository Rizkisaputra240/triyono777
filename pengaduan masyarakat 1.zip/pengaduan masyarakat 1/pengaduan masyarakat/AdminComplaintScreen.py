from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup
from kivy.uix.image import Image
 
# Menyimpan data berita dalam list untuk menampilkan berita
news_data = []
# Halaman Pengaduan
class AdminComplaintScreen(Screen):
    def __init__(self, **kwargs):
        super(AdminComplaintScreen, self).__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Label untuk judul halaman
        layout.add_widget(Label(text="Admin - Pengaduan", font_size=34, bold=True))

        # Daftar pengaduan
        self.complaint_list = BoxLayout(orientation='vertical', size_hint_y=None)
        self.complaint_list.bind(minimum_height=self.complaint_list.setter('height'))
        
        # Menggunakan children untuk menambahkan complaint_list ke dalam ScrollView
        layout.add_widget(ScrollView(size_hint=(1, 0.7), do_scroll_y=True, children=[self.complaint_list]))

        # Tombol navigasi kembali
        button_layout = BoxLayout(size_hint=(1, 0.2), spacing=10)
        button_layout.add_widget(Button(text='Beranda', on_press=lambda x: setattr(self.manager, 'current', 'homeadmin')))
        layout.add_widget(button_layout)

        self.add_widget(layout)

        # Popup akan menjadi atribut kelas untuk akses di seluruh metode
        self.detail_popup = None

    def display_complaints(self, complaints):
        # Menampilkan daftar pengaduan
        for complaint in complaints:
            complaint_button = Button(text=complaint['title'], size_hint_y=None, height=40)
            complaint_button.bind(on_press=lambda btn, c=complaint: self.show_complaint_details(c))
            self.complaint_list.add_widget(complaint_button)

    def show_complaint_details(self, complaint):
        # Menampilkan detail pengaduan dan memungkinkan admin untuk membalas
        self.detail_popup = Popup(title="Detail Pengaduan", size_hint=(0.8, 0.8))

        detail_layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # Deskripsi pengaduan
        detail_layout.add_widget(Label(text=f"Pengaduan: {complaint['description']}", font_size=18))

        # Balasan Admin
        self.reply_input = TextInput(hint_text="Balasan Admin", font_size=18, size_hint_y=0.3, multiline=True)
        detail_layout.add_widget(self.reply_input)

        # Tombol Kirim Balasan
        reply_button = Button(text="Kirim Balasan", size_hint_y=0.2)
        reply_button.bind(on_press=lambda x: self.reply_to_complaint(complaint))
        detail_layout.add_widget(reply_button)

        self.detail_popup.content = detail_layout
        self.detail_popup.open()

    def reply_to_complaint(self, complaint):
        # Fungsi untuk membalas pengaduan
        reply = self.reply_input.text
        if reply:
            print(f"Balasan untuk pengaduan {complaint['title']}: {reply}")
            # Di sini Anda bisa menambahkan logika untuk menyimpan balasan atau status pengaduan
            complaint['reply'] = reply
            self.reply_input.text = ''

            # Tutup popup setelah mengirim balasan
            self.detail_popup.dismiss()



# Aplikasi Utama
class TestApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(AdminComplaintScreen(name='complaint'))
        return sm
if __name__ == '__main__':
    TestApp().run()
