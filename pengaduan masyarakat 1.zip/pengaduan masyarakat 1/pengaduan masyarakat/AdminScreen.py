from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.popup import Popup  # Pastikan Popup diimport

class HomeAdminScreen(Screen):
    def __init__(self, **kwargs):
        super(HomeAdminScreen, self).__init__(**kwargs)

        layout = FloatLayout()

        # Menu layout (hanya Log Out)
        self.menu_layout = BoxLayout(orientation='vertical', size_hint=(0.2, 1), pos_hint={'x': -0.7, 'top': 1}, padding=[10, 10, 10, 750], spacing=50)
        self.menu_layout.add_widget(Button(text="Log Out", size_hint_y=None, height=50, on_press=self.show_logout_confirmation))

        layout.add_widget(self.menu_layout)

        # Button to toggle menu (Hamburger Icon)
        self.menu_button = Button(text='☰', size_hint=(0.1, 0.1), pos_hint={'x': 0, 'top': 1})
        self.menu_button.bind(on_press=self.toggle_menu)
        layout.add_widget(self.menu_button)

        # Informasi Admin
        head_layout = BoxLayout(orientation='vertical', size_hint=(0.9, 0.3), padding=10, pos_hint={'center_x': 0.5, 'top': 0.85})
        head_layout.add_widget(Label(text='Selamat Datang di Admin Dashboard', font_size=24, bold=True, halign='center'))
        layout.add_widget(head_layout)

        # Tombol navigasi ke halaman pengaduan dan berita
        button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10)
        button_layout.add_widget(Button(text='Pengaduan', on_press=lambda x: setattr(self.manager, 'current', 'admincomplaint')))
        button_layout.add_widget(Button(text='Berita', on_press=lambda x: setattr(self.manager, 'current', 'adminaddnews')))
        
        layout.add_widget(button_layout)

        self.add_widget(layout)

    def toggle_menu(self, instance):
        # Menggerakkan menu ke dalam dan keluar
        if self.menu_layout.pos_hint['x'] == -0.7:
            # Show menu
            self.menu_layout.pos_hint = {'x': 0, 'top': 1}
        else:
            # Hide menu
            self.menu_layout.pos_hint = {'x': -0.7, 'top': 1}
        self.menu_layout.canvas.ask_update()

    def show_logout_confirmation(self, instance):
        # Popup to confirm logout
        content = BoxLayout(orientation='vertical', padding=10)
        content.add_widget(Label(text='Ingin Logout Dari Akun Sekarang?'))
        button_layout = BoxLayout(size_hint=(1, 0.2))
        button_layout.add_widget(Button(text='Tidak', on_press=lambda x: self.dismiss_popup()))
        button_layout.add_widget(Button(text='Ya', on_press=self.logout))
        content.add_widget(button_layout)
        
        self.popup = Popup(title='Konfirmasi', content=content, size_hint=(0.8, 0.4))
        self.popup.open()

    def dismiss_popup(self):
        self.popup.dismiss()

    def logout(self, instance):
        self.manager.current = 'login'  # Kembali ke halaman login
        self.popup.dismiss()

# Aplikasi Utama
class TestApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(HomeAdminScreen(name='homeadmin'))
        return sm

if __name__ == '__main__':
    TestApp().run()
