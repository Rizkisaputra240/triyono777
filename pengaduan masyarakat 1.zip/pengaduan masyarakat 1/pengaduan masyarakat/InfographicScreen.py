from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.gridlayout import GridLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.popup import Popup
from kivy.uix.widget import Widget


class InfographicScreen(Screen):
    def __init__(self, **kwargs):
        super(InfographicScreen, self).__init__(**kwargs)
        
        layout = FloatLayout()

        # Menu layout (hidden by default)
        self.menu_layout = BoxLayout(orientation='vertical', size_hint=(0.7, 1), pos_hint={'x': -0.7, 'top': 1}, padding=[10, 570, 550, 570], spacing=10)
        self.menu_layout.add_widget(Button(text="Profil Anda", size_hint_y=None, height=50, on_press=self.go_to_profile))
        self.menu_layout.add_widget(Button(text="Profil Desa", size_hint_y=None, height=50, on_press=self.go_to_village_profile))
        self.menu_layout.add_widget(Button(text="Infographic", size_hint_y=None, height=50, on_press=self.go_to_infographic))
        self.menu_layout.add_widget(Button(text="Log Out", on_press=self.show_logout_confirmation, size_hint_y=None, height=50))
        
        layout.add_widget(self.menu_layout)

        # Button to toggle menu (Hamburger Icon)
        self.menu_button = Button(text='☰', size_hint=(0.1, 0.1), pos_hint={'x': 0, 'top': 1})
        self.menu_button.bind(on_press=self.toggle_menu)
        layout.add_widget(self.menu_button)

        # Bagian Ikon Navigasi Infografis
        icon_layout = GridLayout(cols=3, size_hint=(1, 0.2), pos_hint={'top': 0.9}, padding=[240, 10, 50, 10], spacing=[50, 10])  
        icon_layout.add_widget(Button(text='Penduduk', on_press=self.show_population_data, size_hint=(None, None), size=(200, 100)))
        icon_layout.add_widget(Button(text='APBDes', on_press=self.show_apbdes_data, size_hint=(None, None), size=(200, 100)))
        icon_layout.add_widget(Button(text='Stunting', on_press=self.show_stunting_data, size_hint=(None, None), size=(200, 100)))
        layout.add_widget(icon_layout)

        # Bagian Konten Utama (Infografis)
        self.infographic_content = BoxLayout(orientation='vertical', size_hint=(1, 0.5), pos_hint={'y': 0.2}, padding=[20, 10, 20, 10], spacing=10)
        self.infographic_content.add_widget(Label(text="Pilih salah satu kategori di atas untuk melihat data infografis", font_size=35))
        layout.add_widget(self.infographic_content)

        # Navigasi (Bagian Bawah)
        button_layout = BoxLayout(size_hint=(1, 0.1), spacing=10, pos_hint={'y': 0})
        button_layout.add_widget(Button(text='BERANDA', size_hint=(1, 1), on_press=self.go_to_home))
        button_layout.add_widget(Button(text='PENGADUAN', size_hint=(1, 1), on_press=self.go_to_complaint))
        button_layout.add_widget(Button(text='BERITA', size_hint=(1, 1), on_press=self.go_to_news))
        layout.add_widget(button_layout)

        self.add_widget(layout)

    def toggle_menu(self, instance):
        # Menggerakkan menu ke dalam dan keluar
        if self.menu_layout.pos_hint['x'] == -0.7:
            # Show menu
            self.menu_layout.pos_hint = {'x': 0, 'top': 1}
        else:
            # Hide menu
            self.menu_layout.pos_hint = {'x': -0.7, 'top': 1}
        self.menu_layout.canvas.ask_update()

    def show_logout_confirmation(self, instance):
        # Popup to confirm logout
        content = BoxLayout(orientation='vertical', padding=10)
        content.add_widget(Label(text='Ingin Logout Dari Akun Sekarang?'))
        button_layout = BoxLayout(size_hint=(1, 0.2))
        button_layout.add_widget(Button(text='Tidak', on_press=lambda x: self.dismiss_popup()))
        button_layout.add_widget(Button(text='Ya', on_press=self.logout))
        content.add_widget(button_layout)
        
        self.popup = Popup(title='Konfirmasi', content=content, size_hint=(0.8, 0.4))
        self.popup.open()

    def dismiss_popup(self):
        self.popup.dismiss()

    def logout(self, instance):
        self.manager.current = 'login'
        self.popup.dismiss()

    def go_to_home(self, instance):
        self.manager.current = 'home'

    def go_to_complaint(self, instance):
        self.manager.current = 'complaint'

    def go_to_news(self, instance):
        self.manager.current = 'news'

    def go_to_profile(self, instance):
        self.manager.current = 'profile'

    def go_to_village_profile(self, instance):
        self.manager.current = 'VillageProfile'

    def go_to_infographic(self, instance):
        self.manager.current = 'InfographicScreen'
        
    
    def show_population_data(self, instance):
        self.infographic_content.clear_widgets()
        vbox = BoxLayout(orientation='vertical', spacing=25)
        vbox.add_widget(Label(text="Jumlah Penduduk", font_size=25))
        vbox.add_widget(Image(source='images/jumlah penduduk.png', size_hint=(1, None), height=450, allow_stretch=True))
        self.infographic_content.add_widget(vbox)

    def show_apbdes_data(self, instance):
        self.infographic_content.clear_widgets()
        vbox = BoxLayout(orientation='vertical', spacing=25)
        vbox.add_widget(Label(text="APB Desa Cengklik Tahun 2024", font_size=25))
        vbox.add_widget(Image(source='images/APB.png', size_hint=(1, None), height=450, allow_stretch=True))
        self.infographic_content.add_widget(vbox)

    def show_stunting_data(self, instance):
        self.infographic_content.clear_widgets()
        vbox = BoxLayout(orientation='vertical', spacing=25)
        vbox.add_widget(Label(text="Data Stunting", font_size=25))
        vbox.add_widget(Image(source='images/data stunting.png', size_hint=(1, None), height=450, allow_stretch=True))
        self.infographic_content.add_widget(vbox)
